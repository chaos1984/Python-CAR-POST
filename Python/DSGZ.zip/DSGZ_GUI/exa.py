import numpy as np
import matplotlib.pyplot as plt


def ff1(c1,c2,str1,a=0.):
	return (1-np.power(np.e,-a*str1))
	# return (np.power(np.e,-c1*str1)+np.power(str1,c2))*(1-np.power(np.e,-a*str1))


c1 = 1#np.arange(0.0, 3., 0.01)
c2 = 0
str1=np.arange(0.0, 3., 0.01)


stress = ff1(c1,c2,str1,a=1.)
plt.figure(1)
plt.plot(str1,stress)
plt.grid('on')
plt.show()