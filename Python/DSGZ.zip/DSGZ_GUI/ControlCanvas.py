# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QMenu, QVBoxLayout, QSizePolicy, QMessageBox, QWidget
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5 import NavigationToolbar2QT as NavigationToolbar
import numpy as np

class MyMplCanvas(FigureCanvas):
	def __init__(self, parent=None, width=50, height=50, dpi=100):
		fig = Figure(figsize=(width, height), dpi=dpi)
		self.axes = fig.add_subplot(111)
		# self.axes.set_adjustable('datalim')
		# ÿ��plot()���õ�ʱ������ϣ��ԭ���������ᱻ���(����False)
		self.compute_initial_figure()
		#
		FigureCanvas.__init__(self, fig)
		self.setParent(parent)
 
		FigureCanvas.setSizePolicy(self,
									QSizePolicy.Expanding,
									QSizePolicy.Expanding)
		self.axes.set_xlabel('Strain[-]')
		self.axes.set_ylabel('Stress[GPa]')
		
		FigureCanvas.updateGeometry(self)
 
	def compute_initial_figure(self):
		pass
 
class MyControlMplCanvas(MyMplCanvas):#
	def __init__(self, *args, **kwargs):
		MyMplCanvas.__init__(self, *args, **kwargs)
		# timer = QtCore.QTimer(self)
		# timer.timeout.connect(self.update_figure)
		# timer.start(1000)
 
	def compute_initial_figure(self):
		self.axes.plot([0, 0, 0, 0], [1, 2, 3, 4], 'r')
 
	def update_figure(self,*args):
		# print (len(args[0]))
		args = args[0]
		strainrate = [float(i) for i in args[3]]
		# print (args[0][0])
		strain = np.arange(0.0, 3., 0.01)
		testing = args[1]
		# try:
		if args[2] == 2:
			self.axes.cla()
		legend = []
		for i in range(int(len(testing)/2)):
			self.axes.plot(testing[2*i+0], testing[2*i+1],'--')
			legend.append(i)
		self.axes.legend(legend)
		print ("*\n")
		print ("K\tc1\tc2\tc3\tc4\ta\tm\talpha")
		for index,rate in enumerate(strainrate):

			K = args[0][index][0];
			c1 = args[0][index][1];
			c2 = args[0][index][2];
			c3 = args[0][index][3];c4 = args[0][index][4];m = args[0][index][5];
			a = args[0][index][6];alpha = args[0][index][7]
			print (rate,K,c1,c2,c3,c4,a,m,alpha)
			stress = self.DGSZ(strain,rate,296.,K,c1,c2,c3,c4,a,m,alpha)
			self.axes.plot(strain, stress)
		self.axes.grid('on')
		legend.extend(strainrate)
		self.axes.set_xlabel('Strain[-]')
		self.axes.set_ylabel('Stress[GPa]')
		self.axes.legend(legend)
		self.draw()

	def f_strain(self,strain,c1,c2,a):
		return (np.power(np.e,-c1*strain) + np.power(strain,c2))*(1-np.power(np.e,-a*strain))

	def h_strainrate_T(self,strainrate,m,T,alpha):
		return np.power(strainrate,m)*np.power(np.e,alpha/T)

	def DGSZ(self,strain,strainrate,T,K,c1,c2,c3,c4,a,m,alpha):
		f = self.f_strain(strain,c1,c2,a)
		h = self.h_strainrate_T(strainrate,m,T,alpha)
		value = K * ( f + (strain*np.power(np.e,(1.-strain/(c3*h)))/(c3*h)-f) * np.power(np.e,(np.log(h)-c4)*strain))*h
		#    print (strain*np.power(np.e,(1-strain/(c3*h)))/(c3*h)-f)
		return value


	# def CurveKey(x,y,strainrate_list,curvenum):
		# curvenum = 
		# A = 
		# l0 = 
		# Ymould = 
		# # x,y = CowperSymondsCurve(FDfile[0],A,l0,Ymould_user,80,ratelist,x_p,y_p)
		# fout = open(self.MaterialGrouplematdir,'w')
		# fout.write('*KEYWORD\n')
		# fout.write( "$%10s%10s%10s%10s%10s%10s%10s%10s\n" %('c1','c2','m','a','K','c3','c4','alpha'))
		# fout.write( "$%10.4f%10.4f%10.4f%10.4f%10.4f%10.4f%10.4f%10.4f\n" %(c1,c2,m,a,K,c3,c4,alpha))
		# fout.write('$ Created: ' + time.strftime("%d.%m.%Y %H:%M:%S") + '\n')
		# fout.write("*DEFINE_TABLE\n%d\n" %(curvenum))
		# for i in strainrate_list:
			# fout.write("%f\n" %(np.log(i)))
		# for index,strainrate in enumerate(strainrate_list):
			# res = [ x[index], y[index]]
			# curvenum += 1
			# flag = 0 
			# fout.write('*DEFINE_CURVE_TITLE\nRate %.5f\n' %(strainrate_list[index]))
			# fout.write('$     LCID      SIDR       SFA       SFO      OFFA      OFFO    DATTYP\n')
			# fout.write('      %d         0    1.0000    1.0000    0.0000    0.0000\n' %(curvenum))
			# plt.figure(5)
			# plt.plot(x[index],y[index])
			# plt.grid('on')
			# for i in range(len(x[index])):
				# if x[index][i] > 0:
					# if flag == 0 :
						# fout.write("%f,%f\n" %(0,y[index][i]))
						# flag = 1
					# if flag != 0 :
						# fout.write("%f,%f\n" %(x[index][i],y[index][i]))
		# fout.write("*END\n")
		# fout.close()
		# plt.savefig('curve')
		# return