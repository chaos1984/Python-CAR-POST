# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QMenu, QVBoxLayout, QSizePolicy, QMessageBox, QWidget
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import numpy as np

class MyMplCanvas(FigureCanvas):
	def __init__(self, parent=None, width=50, height=50, dpi=100):
		fig = Figure(figsize=(width, height), dpi=dpi)
		self.axes = fig.add_subplot(111)
		# ÿ��plot()���õ�ʱ������ϣ��ԭ���������ᱻ���(����False)
		self.compute_initial_figure()
 
		#
		FigureCanvas.__init__(self, fig)
		self.setParent(parent)
 
		FigureCanvas.setSizePolicy(self,
									QSizePolicy.Expanding,
									QSizePolicy.Expanding)
		self.axes.set_xlabel('Strain[-]')
		self.axes.set_ylabel('Stress[GPa]')
		FigureCanvas.updateGeometry(self)
 
	def compute_initial_figure(self):
		pass
 
class MyControlMplCanvas(MyMplCanvas):#
	def __init__(self, *args, **kwargs):
		MyMplCanvas.__init__(self, *args, **kwargs)
		# timer = QtCore.QTimer(self)
		# timer.timeout.connect(self.update_figure)
		# timer.start(1000)
 
	def compute_initial_figure(self):
		self.axes.plot([0, 0, 0, 0], [1, 2, 3, 4], 'r')
 
	def update_figure(self,pars=[3.9e-3,0.,1.49,0.0029,11.,0.064,1171.,11.7]):
		# print ('Pars',pars)
		strainrate=[1.,0.1,.01,0.001,0.0001]
		K = pars[0][0];c1 = pars[0][1];c2 = pars[0][2];c3 = pars[0][3];c4 = pars[0][4];m = pars[0][5]
		alpha = pars[0][6];a = pars[0][7]
		strain = np.arange(0.0, 3., 0.01)
		testing = pars[1]
		# try:
		if pars[2] == 2:
			self.axes.cla()
		legend = []
		for i in range(int(len(testing)/2)):
			self.axes.plot(testing[2*i+0], testing[2*i+1],'--')
			legend.append(i)
		self.axes.legend(legend)
		for rate in strainrate:
			stress = self.DGSZ(strain,rate,296.,K,c1,c2,c3,c4,a,m,alpha)
			# self.axes.cla()
			self.axes.plot(strain, stress)
			self.axes.grid('on')
		legend.extend(strainrate)
		self.axes.set_xlabel('Strain[-]')
		self.axes.set_ylabel('Stress[GPa]')
		self.axes.legend(legend)
		self.draw()
		# except:
			# pass
		#
		
	def f_strain(self,strain,c1,c2,a):
		return (np.power(np.e,-c1*strain) + np.power(strain,c2))*(1-np.power(np.e,-a*strain))

	def h_strainrate_T(self,strainrate,m,T,alpha):
		return np.power(strainrate,m)*np.power(np.e,alpha/T)

	def DGSZ(self,strain,strainrate,T,K,c1,c2,c3,c4,a,m,alpha):
		f = self.f_strain(strain,c1,c2,a)
		h = self.h_strainrate_T(strainrate,m,T,alpha)
		value = K * ( f + (strain*np.power(np.e,(1.-strain/(c3*h)))/(c3*h)-f) * np.power(np.e,(np.log(h)-c4)*strain))*h
		#    print (strain*np.power(np.e,(1-strain/(c3*h)))/(c3*h)-f)
		return value

		
		
		
		
		
		
		
